import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { selectUser, setUsers, fetchPostsByUser } from './store';
import './App.css';

export default function App() {
  const dispatch = useDispatch();

  // селекторы(store)
  const users = useSelector((state) => state.users.list);
  const selectedId = useSelector((state) => state.users.selectedId);
  const posts = useSelector((state) => state.posts.list);
  const postsStatus = useSelector((state) => state.posts.status);

  // список юзеров (+фетч)
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((res) => res.json())
      .then((data) => dispatch(setUsers(data)));
  }, [dispatch]);

  // выбор юзера и загрузка его постов
  const handleSelectUser = (userId) => {
    dispatch(selectUser(userId));
    dispatch(fetchPostsByUser(userId)); // фильтр через .filter() происходит внутри thunk
  };

  const selectedUser = users.find((u) => u.id === selectedId);

  return (
    <div className="app">
      {/* лефт борд / список юзеров */}
      <aside className="sidebar">
        <h2 className="sidebar__title">Пользователи</h2>
        <ul className="user-list">
          {users.map((user) => (
            <li key={user.id}>
              <button
                className={`user-btn ${user.id === selectedId ? 'user-btn--active' : ''}`}
                onClick={() => handleSelectUser(user.id)}
              >
                <span className="user-btn__avatar">
                  {user.name.slice(0, 2).toUpperCase()}
                </span>
                <span className="user-btn__info">
                  <span className="user-btn__name">{user.name}</span>
                  <span className="user-btn__username">@{user.username}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      </aside>

      {/* правая панель(посты выбранного юзера) */}
      <main className="posts-panel">
        <h2 className="posts-panel__title">
          {selectedUser ? `Посты: ${selectedUser.name}` : 'Выберите пользователя'}
        </h2>

        {!selectedId && (
          <p className="posts-panel__placeholder">
            Нажмите на пользователя слева, чтобы увидеть его посты.
          </p>
        )}

        {postsStatus === 'loading' && <p className="posts-panel__loading">Загрузка...</p>}

        {postsStatus === 'succeeded' && (
          <ul className="post-list">
            {posts.map((post) => (
              <li key={post.id} className="post-card">
                <h3 className="post-card__title">{post.title}</h3>
                <p className="post-card__body">{post.body}</p>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}
