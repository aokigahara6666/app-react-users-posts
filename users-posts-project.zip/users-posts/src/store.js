import { configureStore, createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// async thunk(загрузка и фильтр постов по юзерке)
export const fetchPostsByUser = createAsyncThunk(
  'posts/fetchByUser',
  async (userId) => {
    const response = await fetch('https://jsonplaceholder.typicode.com/posts');
    const allPosts = await response.json();
    // фильтр(посты только по юзерке)
    return allPosts.filter((post) => post.userId === userId);
  }
);

// юзслайсы
const usersSlice = createSlice({
  name: 'users',
  initialState: {
    list: [],
    selectedId: null,
    status: 'idle',
  },
  reducers: {
    selectUser(state, action) {
      state.selectedId = action.payload;
    },
    setUsers(state, action) {
      state.list = action.payload;
    },
  },
});

// постслайсы
const postsSlice = createSlice({
  name: 'posts',
  initialState: {
    list: [],
    status: 'idle', // айдл лоад фейл успех****
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchPostsByUser.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchPostsByUser.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.list = action.payload;
      })
      .addCase(fetchPostsByUser.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      });
  },
});

export const { selectUser, setUsers } = usersSlice.actions;

export const store = configureStore({
  reducer: {
    users: usersSlice.reducer,
    posts: postsSlice.reducer,
  },
});
